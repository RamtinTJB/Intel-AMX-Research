import torch
import time
import functools
import numpy as np

def timer(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        print(f"{func.__name__} executed in {end-start:.6f} seconds")
        return result
    return wrapper

@timer
def matmul_torch(A, B):
    return torch.matmul(A, B)

@timer
def matmul_amx(A, B):
    with torch.amp.autocast('cpu', dtype=torch.bfloat16):
        res = torch.matmul(A, B)
        return res

@timer
def matmul_np(A, B):
    return np.matmul(A, B)

size = 8192*2
A = torch.randn(size, size, device="cpu", dtype=torch.float32)
B = torch.randn(size, size, device="cpu", dtype=torch.float32)

matmul_torch(A, B)
matmul_amx(A, B)
matmul_np(A, B)
