import ctypes
import numpy as np
import time

# 1) Load the shared library we compiled
amx_lib = ctypes.cdll.LoadLibrary("./libamxmatmul.so")

# 2) Specify argument and return types for amx_matmul
#    void amx_matmul(const float *A, const float *B, float *C, int N)
amx_lib.amx_matmul.argtypes = (
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.c_int
)
amx_lib.amx_matmul.restype = None

def amx_matmul_py(A: np.ndarray, B: np.ndarray) -> np.ndarray:
    """
    Python wrapper around the C function amx_matmul, using ctypes.
    A, B are (N,N) float32 arrays, returns C (N,N).
    """
    N = A.shape[0]
    C = np.zeros((N, N), dtype=np.float32)

    # Convert A, B, C to pointers
    A_ptr = A.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
    B_ptr = B.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
    C_ptr = C.ctypes.data_as(ctypes.POINTER(ctypes.c_float))

    # Call the C function
    amx_lib.amx_matmul(A_ptr, B_ptr, C_ptr, N)
    return C

if __name__ == "__main__":
    N = 8096  # Must be multiple of 16 in this naive code

    # Create random float32 data
    A = np.random.randn(N, N).astype(np.float32)
    B = np.random.randn(N, N).astype(np.float32)

    # -- Benchmark our naive AMX approach --
    start = time.perf_counter()
    C_amx = amx_matmul_py(A, B)
    end = time.perf_counter()
    print(f"AMX matmul: {end - start:.6f} seconds")

    # -- Compare with NumPy matmul --
    start = time.perf_counter()
    C_np = A @ B
    end = time.perf_counter()
    print(f"NumPy matmul: {end - start:.6f} seconds")

    # Optional correctness check
    diff = np.linalg.norm(C_amx - C_np, ord='fro')
    print(f"Frobenius norm difference between AMX and NumPy = {diff:.6f}")

